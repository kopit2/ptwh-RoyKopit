The folder 'webapp-rk' contains all the files that run the application
the html pages are in the templates folder.
if you what to test the app you can run it locally or on this link: http://wh-t1-rk.herokuapp.com/

The pdf file is the second challenge and it is the report+pictures in the fourth chapter